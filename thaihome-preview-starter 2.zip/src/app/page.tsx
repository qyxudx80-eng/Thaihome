const samples = [
  {title:"Pattaya Sea View Residence", area:"芭提雅 · 中天", type:"出售", price:"฿3,500,000"},
  {title:"Private Pool Villa", area:"芭提雅 · 东区", type:"出租", price:"฿65,000 / 月"},
  {title:"Bangkok City Condo", area:"曼谷 · 素坤逸", type:"出售", price:"฿5,200,000"}
];
export default function Home() {
  return <>
    <header><div className="inner"><a className="brand" href="/">ThaiHome</a><nav><a href="/">首页</a><a href="#listings">房源</a><a href="#about">关于我们</a><a href="#contact">联系我们</a><span>中文 / EN / TH</span></nav></div></header>
    <main className="container">
      <section className="hero">
        <span className="pill">THAILAND PROPERTY</span>
        <h1>在泰国，找到理想的家</h1>
        <p>精选泰国优质房源，覆盖芭提雅、曼谷和普吉岛。支持中文、English、ภาษาไทย。</p>
        <form className="search" action="/properties">
          <select name="type" aria-label="交易类型"><option value="">出售或出租</option><option value="SALE">出售</option><option value="RENT">出租</option></select>
          <select name="area" aria-label="地区"><option value="">选择地区</option><option>芭提雅</option><option>曼谷</option><option>普吉岛</option></select>
          <input name="q" placeholder="输入地区或房源关键词"/>
          <button>搜索房源</button>
        </form>
      </section>
      <section id="listings">
        <h2>精选房源</h2><p className="muted">以下为开发阶段的示例展示，非真实挂牌信息。</p>
        <div className="cards">{samples.map((x)=><article className="card" key={x.title}><div style={{height:125,background:"#e5edf5",borderRadius:10,display:"grid",placeItems:"center",color:"#68829a"}}>房源图片区域</div><p><span className="pill">{x.type}</span></p><h3>{x.title}</h3><p className="muted">{x.area}</p><div className="price">{x.price}</div></article>)}</div>
      </section>
      <section id="about" className="panel" style={{marginTop:28}}><h2>关于 ThaiHome</h2><p>专注泰国房地产租售服务，为客户提供清晰、可靠的房源信息与沟通渠道。</p></section>
      <section id="contact" className="panel" style={{marginTop:16}}><h2>联系 ThaiHome</h2><p className="muted">LINE · WhatsApp · 电话 · 在线咨询（正式接入时配置）</p></section>
    </main><footer>© {new Date().getFullYear()} ThaiHome. All rights reserved.</footer>
  </>;
}
